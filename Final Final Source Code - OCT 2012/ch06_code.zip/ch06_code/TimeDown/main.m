//
//  main.m
//  TimeDown
//
//  Created by Bear Cahill on 8/2/10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TimeDownAppDelegate.h"

int main(int argc, char *argv[]) {
    
    int retVal = 0;
    @autoreleasepool {
        retVal = UIApplicationMain(argc, argv, nil, NSStringFromClass([TimeDownAppDelegate class]));
    }
    return retVal; 
}
