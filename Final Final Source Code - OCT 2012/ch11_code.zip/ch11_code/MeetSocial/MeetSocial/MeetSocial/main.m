//
//  main.m
//  MeetSocial
//
//  Created by Bear Cahill on 7/21/12.
//  Copyright (c) 2012 BrainwashInc.com. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "MSAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([MSAppDelegate class]));
    }
}
