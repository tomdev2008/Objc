//
//  SVCSplitVController.h
//  Rayjobs
//
//  Created by Bear Cahill on 12/15/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SVCSplitVController : UISplitViewController <UISplitViewControllerDelegate> {

	IBOutlet UIToolbar *tbTop;
	IBOutlet UIView *detailsView;

	UIView *displayedView;
	UIPopoverController *popover;
}

@end
