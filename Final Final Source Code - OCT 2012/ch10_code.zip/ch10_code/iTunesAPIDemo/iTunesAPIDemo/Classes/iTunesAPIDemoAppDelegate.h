//
//  iTunesAPIDemoAppDelegate.h
//  iTunesAPIDemo
//
//  Created by Bear Cahill on 1/13/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface iTunesAPIDemoAppDelegate : NSObject <UIApplicationDelegate> {
    
    UIWindow *window;
    UIViewController *mainController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet UIViewController *mainController;

@end

