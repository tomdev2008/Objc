//
//  VCDecorations.h
//  PicDecor
//
//  Created by Bear Cahill on 12/20/09.
//  Copyright 2009 Brainwash Inc.. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VCDecorations : UIViewController {

	UIImage *selectedImage;
}

@property (nonatomic, retain) UIImage *selectedImage;

-(IBAction)doImageBtn:(id)sender;
-(IBAction)doCancelBtn:(id)sender;

@end
