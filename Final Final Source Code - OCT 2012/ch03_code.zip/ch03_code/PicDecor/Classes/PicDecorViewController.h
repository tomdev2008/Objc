//
//  PicDecorViewController.h
//  PicDecor
//
//  Created by Bear Cahill on 12/20/09.
//  Copyright Brainwash Inc. 2009. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VCImageEditing.h";
#import "VCAbout.h"

@interface PicDecorViewController : UIViewController <UIImagePickerControllerDelegate, UINavigationControllerDelegate> {

	IBOutlet VCImageEditing *vcImageEditing;

	IBOutlet VCAbout *vcAbout;
}

-(IBAction)doCameraBtn:(id)sender;
-(IBAction)doPhotoAlbumBtn:(id)sender;

-(IBAction)doAboutBtn:(id)sender;

@end
