//
//  PicDecorAppDelegate.m
//  PicDecor
//
//  Created by Bear Cahill on 12/20/09.
//  Copyright Brainwash Inc. 2009. All rights reserved.
//

#import "PicDecorAppDelegate.h"
#import "PicDecorViewController.h"

@implementation PicDecorAppDelegate

@synthesize window;
@synthesize viewController;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    
    
    // Override point for customization after app launch    
    [window addSubview:viewController.view];
    [window makeKeyAndVisible];
}


- (void)dealloc {
    [viewController release];
    [window release];
    [super dealloc];
}


@end
