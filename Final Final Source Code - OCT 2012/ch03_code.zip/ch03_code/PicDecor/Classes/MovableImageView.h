//
//  MovableImage.h
//  
//
//  Created by Bear Cahill on 12/20/09.
//  Copyright 2009 Brainwash Inc.. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MovableImageView : UIImageView {

}


@end


