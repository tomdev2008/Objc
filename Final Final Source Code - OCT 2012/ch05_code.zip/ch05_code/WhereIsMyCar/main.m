//
//  main.m
//  WhereAmIParked
//
//  Created by Bear Cahill on 1/29/10.
//  Copyright Brainwash Inc. 2010. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WhereAmIParkedAppDelegate.h"

int main(int argc, char *argv[]) {
    int retVal = 0;
    @autoreleasepool {
        retVal = UIApplicationMain(argc, argv, nil, NSStringFromClass([WhereAmIParkedAppDelegate class]));
    }
    return retVal; 
}
