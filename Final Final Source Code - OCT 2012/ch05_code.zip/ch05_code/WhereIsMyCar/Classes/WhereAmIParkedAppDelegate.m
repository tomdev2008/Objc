//
//  WhereAmIParkedAppDelegate.m
//  WhereAmIParked
//
//  Created by Bear Cahill on 1/29/10.
//  Copyright Brainwash Inc. 2010. All rights reserved.
//

#import "WhereAmIParkedAppDelegate.h"
#import "WhereAmIParkedViewController.h"

@implementation WhereAmIParkedAppDelegate

@synthesize window;
@synthesize viewController;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    
    
    // Override point for customization after app launch    
    [window addSubview:viewController.view];
    [window makeKeyAndVisible];
}




@end
