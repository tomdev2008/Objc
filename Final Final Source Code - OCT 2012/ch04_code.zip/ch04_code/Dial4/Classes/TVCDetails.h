//
//  TVCDetails.h
//  Dial4
//
//  Created by Bear Cahill on 12/21/09.
//  Copyright 2009 Brainwash Inc.. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AddressBook/AddressBook.h>


@interface TVCDetails : UITableViewController {

	ABRecordRef person;

}

@property (nonatomic, assign) ABRecordRef person;

@end
