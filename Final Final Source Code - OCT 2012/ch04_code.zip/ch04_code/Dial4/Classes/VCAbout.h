//
//  VCAbout.h
//  PicDecor
//
//  Created by Bear Cahill on 1/11/10.
//  Copyright 2010 Brainwash Inc.. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface VCAbout : UIViewController {

}

-(IBAction)doBookBtn:(id)sender;
-(IBAction)doDoneBtn:(id)sender;

@end
