//
//  Dial4AppDelegate.h
//  Dial4
//
//  Created by Bear Cahill on 12/21/09.
//  Copyright Brainwash Inc. 2009. All rights reserved.
//

@interface Dial4AppDelegate : NSObject <UIApplicationDelegate> {
    
    UIWindow *window;
    UINavigationController *navigationController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet UINavigationController *navigationController;

@end

