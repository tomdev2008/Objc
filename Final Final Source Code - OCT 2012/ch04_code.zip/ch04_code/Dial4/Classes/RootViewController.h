//
//  RootViewController.h
//  Dial4
//
//  Created by Bear Cahill on 12/21/09.
//  Copyright Brainwash Inc. 2009. All rights reserved.
//

#import <AddressBook/AddressBook.h>
#import "TVCDetails.h"

#import "VCAbout.h"

@interface RootViewController : UITableViewController {
	NSArray *myContacts;
	ABAddressBookRef addressBook;
	
	IBOutlet VCAbout* vcAbout;
	
	int prevSearchTextLen;
}

-(IBAction)doAboutBtn:(id)sender;

@end
