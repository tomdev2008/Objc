//
//  main.m
//  Dial4
//
//  Created by Bear Cahill on 12/21/09.
//  Copyright Brainwash Inc. 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Dial4AppDelegate.h"

int main(int argc, char *argv[]) {
    int retVal = 0;
    @autoreleasepool {
        retVal = UIApplicationMain(argc, argv, nil, NSStringFromClass([Dial4AppDelegate class]));
    }
    return retVal; 
    
//    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
//    int retVal = UIApplicationMain(argc, argv, nil, nil);
//    [pool release];
//    return retVal;
}
