//
//  AppPlayList.m
//  PlayMyLists
//
//  Created by Bear Cahill on 11/30/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "AppPlayList.h"


@implementation AppPlayList

@dynamic name;
@dynamic tracks;

@end
