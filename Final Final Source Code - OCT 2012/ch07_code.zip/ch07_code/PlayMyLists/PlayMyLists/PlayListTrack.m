//
//  PlayListTrack.m
//  PlayMyLists
//
//  Created by Bear Cahill on 11/30/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "PlayListTrack.h"
#import "AppPlayList.h"


@implementation PlayListTrack

@dynamic persistentID;
@dynamic playlist;

@end
